import React,{useState} from 'react'
import {NativeSelect,Select} from '@material-ui/core'
import { createStyles, makeStyles, Theme } from '@material-ui/core/styles';
import axios from 'axios'
import { setupCache } from 'axios-cache-adapter'
import Bank_List from './Bank_List'

const useStyles = makeStyles( Theme =>
  createStyles({
    menu: {
     width:'20%',
     marginTop:'5%',
     marginLeft:'8%'
    },
  }),
);
const Select_Menu=()=>{
    const classes = useStyles();
    const [city, setCity] = React.useState('');
    const [list,setList]= React.useState([ {bank_id:1,bank_name:"Abc Bank",state:"delhi",ifsc:3235}])
    const cache = setupCache({
        maxAge: 15 * 60 * 1000
      })
    const api = axios.create({
        adapter: cache.adapter
      })
      
    const handleChange = event => {
      setCity(event.target.value);
      console.log(city)
      /*api({
        url: `https://vast-shore-74260.herokuapp.com/banks?city=${event.target.value}`,
        method: 'get'
      }).then(async (response) => {
        Do something fantastic with response.data \o/
        console.log( response)
       
        // Interacting with the store, see `localForage` API.
        const length = await cache.store.length()
       
        console.log( length)
      })*/
     axios.get(`https://vast-shore-74260.herokuapp.com/banks?city=${event.target.value}`,
      )
      .then(function (response) {
        console.log(response);
        //<Bank_List response={response}/>
        setList([...response.data])
        console.log(list)
        console.log(response.data)
      })
      .catch(function (error) {
        console.log(error);
      })
      

    };
  
    return(
        <div>
        <NativeSelect
              id="demo-customized-select-native"
               value={city}
               onChange={handleChange}
               className={classes.menu}
         >
              <option value="null">Select City Name</option>
              <option value="DELHI">DELHI</option>
              <option value="MUMBAI">MUMBAI</option>
             <option value="CHENNAI">CHENNAI</option>
             <option value="DEHRADUN">DEHRADUN</option>
             <option value="KOLKATA">KOLKATA</option>

         </NativeSelect>
         <Bank_List list_bank={list}/> 
   </div>
    )
}
export default Select_Menu